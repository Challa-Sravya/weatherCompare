import React, { Component } from 'react'
import './components/styles.css';
import CitiesList from './components/CitiesList';
import TempConv from './components/TempConv';
import WeatherHeading from './components/WeatherHeading';

export class App extends Component {
  state = {
    loading: true,
    clicked: false,
    cities: [],
    selectedCities: [{}, {}],
    tempState: 'Celcius',
  }

  async componentDidMount() {
    let citiesData = [];
    const url = "https://raw.githubusercontent.com/dr5hn/countries-states-cities-database/master/countries%2Bstates%2Bcities.json";
    const response = await fetch(url);
    const data = await response.json();
    //console.log(data[0].states[0].cities[0]);
    //loops through contries,states and cities
    for (let i = 0; i < data.length; i++) {
      for (let j = 0; j < data[i].states.length; j++) {
        for (let k = 0; k < data[i].states[j].cities.length; k++) {
          const city = data[i].states[j].cities[k];
          city.timezone = data[i].timezones[0].gmtOffsetName;
          // citiesData.push(city);
          let c = citiesData.length < 1000 ? citiesData.push(city) : () => { }
        }
      }
    }
    //console.log(citiesData, typeof (citiesData));
    this.setState({ cities: citiesData, loading: false },
    );
  }

  //get the city data from citiesList.js on changing the city value
  addSelectedCity = (city, id) => {
    const _city = {
      name: city,
      temp: '',
      timezone: '',
      tconv: '',
      state: '',
    };
    const final = [...this.state.selectedCities];
    if (id == 0) {
      final[0] = _city;
    }
    else if (id == 1) {
      final[1] = _city;
    }
    this.setState({
      selectedCities: final,
    });
  }

  //function to get the temperature of city from api
  getCityData = async (cityName) => {
    for (let i = 0; i < this.state.cities.length; i++) {
      if (this.state.cities[i].name === cityName) {
        let url1 = "https://www.7timer.info/bin/astro.php?lon=" + this.state.cities[i].longitude + "&lat=" + this.state.cities[i].latitude + "&ac=0&unit=metric&output=json&tzshift=0";
        const response1 = await fetch(url1);
        const data1 = await response1.json();
        let temp = data1.dataseries[0].temp2m;
        //console.log(temp);
        return temp;
      }
    }
  }

  //function to get the timezone of the city
  getCityTimezone = (cityName) => {
    let tzone = '';
    const found = this.state.cities.findIndex((cdata) => {
      return cdata.name === cityName;
    })
    //console.log("index", found);
    if (found >= 0) {
      tzone = this.state.cities[found].timezone;
    }
    return tzone;
  }

  //function to handle the compare button
  handleCompare = async () => {
    //to check the the input is valid or not
    if (this.state.selectedCities[0].temp === undefined || this.state.selectedCities[1].temp === undefined) {
      alert("Choose a valid city!");
      return;
    }
    this.setState({
      loading: true,
      clicked: true,
    });

    const temp1 = await this.getCityData(this.state.selectedCities[0].name);
    const temp2 = await this.getCityData(this.state.selectedCities[1].name);
    const final = [...this.state.selectedCities];
    final[0].temp = temp1;
    final[1].temp = temp2;
    //to compare the temperatures
    if (temp1 === temp2 && temp1 !== undefined && temp2 !== undefined) {
      console.log("entered equals");
      final[0].state = 'eq';
      final[1].state = 'eq';
    }
    if (temp1 > temp2) {
      final[0].state = 'ge';
      final[1].state = 'le';
    }
    if (temp1 < temp2) {
      final[0].state = 'le';
      final[1].state = 'ge';
    }
    //to display the temperatures when the radio buttons are in previous state 
    if (this.state.tempState === 'Celcius') {
      final[0].tconv = temp1;
      final[1].tconv = temp2;
    }
    if (this.state.tempState === 'Fahrenheit') {
      final[0].tconv = Math.round(temp1 * (9 / 5) + 32);
      final[1].tconv = Math.round(temp2 * (9 / 5) + 32);
    }

    const timezone1 = this.getCityTimezone(this.state.selectedCities[0].name);
    const timezone2 = this.getCityTimezone(this.state.selectedCities[1].name);
    final[0].timezone = timezone1;
    final[1].timezone = timezone2;
    this.setState({
      loading: false,
      selectedCities: final,
    });
  }

  //function to handle the change in radio buttons from TempConv.js
  onChangeUnit = async (event) => {
    this.setState({
      clicked: true,
      tempState: event.target.value,//to store the selected value
    })
    //console.log(event.target.value);
    let t1 = this.state.selectedCities[0].temp;
    let t2 = this.state.selectedCities[1].temp;
    const final = [...this.state.selectedCities];
    //temperature conversion based on selected unit
    if (event.target.value === "Celcius") {
      //console.log("c clicked");
      final[0].tconv = t1;
      final[1].tconv = t2;
    }
    else if (event.target.value === "Fahrenheit") {
      //console.log("f clicked");
      final[0].tconv = Math.round(t1 * (9 / 5) + 32);
      final[1].tconv = Math.round(t2 * (9 / 5) + 32);
    }
    this.setState({
      selectedCities: final,
    });
  }

  render() {
    return (

      <div className='container'>
        <div className="header">
          <WeatherHeading heading="WeatherCompare" />
        </div>
        <div>
          {this.state.loading ? <div>loading...</div> : null}
          <div className='left'>
            <CitiesList className="left" citiesList={this.state.cities} addSelectedCity={this.addSelectedCity} id='0' selected={this.state.selectedCities[0]} />
          </div>
          <div className=''>
            <button className="compare-btn" onClick={this.handleCompare}>COMPARE</button>
          </div >
          <div className="right">
            <CitiesList className="right" citiesList={this.state.cities}
              addSelectedCity={this.addSelectedCity} id='1' selected={this.state.selectedCities[1]} />
          </div>
        </div>
        {this.state.clicked ?
          <div className="radio-btn">
            <TempConv selected={this.state.selectedCities} onChangeUnit={this.onChangeUnit} />
          </div> : null}
      </div>
    );
  }
}
export default App
