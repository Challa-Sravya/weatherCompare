import React, { Component } from 'react'
import './styles.css';
export class CitiesList extends Component {
    //to get value on change from dropdown
    getValue = async (event) => {
        //console.log(event.target.value);
        this.props.addSelectedCity(event.target.value, this.props.id)
    }

    render() {
        const { name = '', temp = '', timezone = '', tconv = '', state = '' } = this.props.selected;
        let citiesList = this.props.citiesList.map((item, i) => {
            return (
                <option key={i} value={item.name}> {item.name} </option>
            )
        }, this);
        //to set the color of temp on comparing the temperatures
        let color = 'white';
        if (state === 'le') {
            color = 'green';
        }
        if (state === 'ge') {
            color = 'red';
        }
        if (state === 'eq') {
            color = 'rgb(16, 16, 59)';
        }

        return (
            <>
                <select id="drop1" className="citySelect" onChange={this.getValue} >
                    <option value='Choose The city...'>Choose The city...</option>
                    {citiesList}
                </select>
                <div className='content'>
                    <p className='zone'>
                        {timezone}
                    </p>
                    <p style={{ color, borderStyle: 'solid', borderRadius: '50%', padding: '15px', height: '70%', width: '70%', display: 'inline-block' }} className='temp'> {tconv}&deg;
                    </p>
                </div>
            </>
        )
    }
}

export default CitiesList
