import React, { Component } from 'react'

export class TempConv extends Component {
    //for the radio buttons
    render() {
        return (
            <>
                <div onChange={this.props.onChangeUnit}>
                    <input type="radio" value="Celcius" name="unit" id="c" defaultChecked /> Celcius <br />
                    <input type="radio" value="Fahrenheit" name="unit" id="f" /> Fahrenheit
                </div>

            </>
        )
    }
}

export default TempConv
