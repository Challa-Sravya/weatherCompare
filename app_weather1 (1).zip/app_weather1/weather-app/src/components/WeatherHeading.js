import React, { Component } from 'react'

export class WeatherHeading extends Component {
    //for the Weather heading
    render() {
        return (
            <div>
                <h1>{this.props.heading}</h1>
            </div>
        )
    }
}

export default WeatherHeading
